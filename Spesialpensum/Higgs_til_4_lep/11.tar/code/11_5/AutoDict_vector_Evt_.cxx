#include "vector"
#include "/work/kkroeni/documents/book_statistics/book_20121026/statbook/exerlutions/11/code/11_5/./Measurement.C"
#ifdef __CINT__ 
#pragma link C++ nestedclasses;
#pragma link C++ nestedtypedefs;
#pragma link C++ class vector<Evt>+;
#pragma link C++ class vector<Evt>::*;
#ifdef G__VECTOR_HAS_CLASS_ITERATOR
#pragma link C++ operators vector<Evt>::iterator;
#pragma link C++ operators vector<Evt>::const_iterator;
#pragma link C++ operators vector<Evt>::reverse_iterator;
#endif
#endif
